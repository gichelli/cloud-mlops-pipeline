# Dummy training script
print('Training model...')