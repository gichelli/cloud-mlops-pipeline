# Dummy inference service
print('Running inference...')